def namaste_duniya():
    print "namaste duniya"