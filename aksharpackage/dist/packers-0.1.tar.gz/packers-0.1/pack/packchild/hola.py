def hola():
    print "hola"